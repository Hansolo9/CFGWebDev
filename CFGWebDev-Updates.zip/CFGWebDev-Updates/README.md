# CFGWebDev

This project consists of two HTML files and one CSS files as a minimum. JavaScript files will also be included. 

The webpage should run from the landing_page.html file. 
