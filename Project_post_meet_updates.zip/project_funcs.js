function submitSuccess () {
    alert("Submitted successfully")
}

function underConstruction () {
    alert("This page is coming soon")
}