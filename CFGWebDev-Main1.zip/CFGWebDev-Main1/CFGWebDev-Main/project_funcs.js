function submitSuccess () {
    let x = document.getElementById("form__error");
    // assign the value of the form to the variables
    // get all tags with the class maintext 
    let maintext = document.getElementsByClassName("maintext")


    if (document.getElementById("name").value == "" || document.getElementById("surname").value == "" || document.getElementById("email").value == "" || document.getElementById("socialp").value == "" || document.getElementById("socialh").value == "" || document.getElementById("bname").value == "" || document.getElementById("url").value == "" || document.getElementById("bsocialp").value == "" || document.getElementById("bsocialh").value == "") {
        x.style.display = "block";
        // change all values that have the maintext class to red
        // since maintext is an array, we need to loop through it
        // from 0 to the length of the array being the number of elements in the list

        for (let i = 0; i < maintext.length; i++) {
            maintext[i].style.borderColor = "#d50000";
            maintext[i].style.color = "#d50000";
            maintext[i].style.background = "#fff8f8";
        }

        

    } else {
        // if the form is filled in, then alert the user that the form has been submitted
        x.style.display = "none";
        for (let i = 0; i < maintext.length; i++) {
          maintext[i].style.borderColor = "#dddddd";
          maintext[i].style.color = "#000000";
          maintext[i].style.background = "#f9f9f9;";
        }
        alert("Form submitted");
    }
    
}

function underConstruction () {
    alert("This function is coming soon")
}

// document.addEventListener('DOMContentLoaded', function() {
//     document.querySelectorAll('.maintext').forEach(function (input) {
//         input.addEventListener('input',function () {
//             input.className = this.className.replace(/form__input--error ?/, '');
//         })
//     });
// });

