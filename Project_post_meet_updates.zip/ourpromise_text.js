document.addEventListener('DOMContentLoaded', function() {

const paragraph1 = document.getElementById("p1")

paragraph1.innerText = 
`We started this page as people who want to bring more sustainability to our everyday lives.
One of the places we are starting is in how we source our fashion. 
Through research we have found some brands that we’d like to explore; each with a different style.

`;

document.body.appendChild(paragraph1);

const paragraph2 = document.getElementById("p2")
paragraph2.innerText = 
`If you are browsing the site and have come across a sustainable brand that you love, but is not mentioned site-wide, 
please let us know by filling in the details of the brand: socials, links to their online shop, features in magazines etc.

`;

document.body.appendChild(paragraph2);

const paragraph3 = document.getElementById("p3")
paragraph3.innerText = 
`This way the word gets round and we can grow our reach to all sustainable brands, big or small.

`
document.body.appendChild(paragraph3);


})