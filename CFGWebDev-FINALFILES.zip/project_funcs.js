function submitSuccess () {
    alert("Submitted successfully")
}

function underConstruction () {
    alert("This function is coming soon")
}